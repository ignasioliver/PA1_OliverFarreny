package exer_00_PPB;

public class Exer_00_PPB {
	// LAUNCHER
	public static void main(String[] args) {
		
		Synchronizer sync = new Synchronizer();
		Ping1 ping = new Ping1(sync);
		Pong1 pong = new Pong1(sync);
		Bang1 bang = new Bang1(sync);
		
		System.out.println("lets go");
		
		ping.start();
		pong.start();
		bang.start();
		
		Synchronizer.sleepAWhile(5000);
		
		ping.stop();
		pong.stop();
		bang.stop();
	}
}

class Synchronizer {
	
	/* available pings, pongs and bangs */
	private volatile int pings = 1;  // can ping once
	private volatile int pongs = 0;  // can't pong
	private volatile int bangs = 0;  // can't bang
	
	public void letMePing() {
		while (pings==0) {sleepAWhile(1);}
		pings = 0;
	}
	
	public void letMePong() {
		while (pongs == 0) {sleepAWhile(1);}
		pongs--;
	}
	
	public void letMeBang() {
		while (bangs==0) {sleepAWhile(1);}
		bangs = 0;
	}
	
	public void pingDone() {
		pongs = 2;
	}
	
	public void pongDone() {
		if (pongs==0) bangs=1;
	}
	
	public void bangDone() {
		pings = 1;
	}
	
	// convenience method.
	protected static void sleepAWhile(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException ie) {
		}
	}
}

class Ping1 extends Thread {
	private Synchronizer synchronizer;
	
	public Ping1 (Synchronizer synchronizer) {
		this.synchronizer = synchronizer; }
	
	public void run () {
		while (true) {
			synchronizer.letMePing();
			System.out.print("PING ");
			synchronizer.pingDone();
		}
	}
}

class Pong1 extends Thread {
	private Synchronizer synchronizer;
	
	public Pong1 (Synchronizer synchronizer) {
		this.synchronizer = synchronizer;}
	
	public void run () {
		while (true) {
			synchronizer.letMePong();
			System.out.print("pong ");
			synchronizer.pongDone();
		}
	}
}

class Bang1 extends Thread {

	private Synchronizer synchronizer;
	
	public Bang1 (Synchronizer synchronizer) {
		this.synchronizer = synchronizer;}
	
	public void run () {
		while (true) {
			synchronizer.letMeBang();
			System.out.println("BANG!");
			synchronizer.bangDone();
		}
	}
}
