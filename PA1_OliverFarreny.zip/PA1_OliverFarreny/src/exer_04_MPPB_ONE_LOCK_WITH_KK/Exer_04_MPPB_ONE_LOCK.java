package exer_04_MPPB_ONE_LOCK_WITH_KK;

import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.*;

public class Exer_04_MPPB_ONE_LOCK {
	// LAUNCHER
	public static void main(String[] args) {
		final int HOW_MANY = 10;

		Ping[] thePings = new Ping[HOW_MANY];
		Pong[] thePongs = new Pong[HOW_MANY];
		Bang[] theBangs = new Bang[HOW_MANY];

		Synchronizer sync = new Synchronizer();
		
		KitKat kitkat = new KitKat(sync);

		kitkat.start();
		for (int i = 0; i < HOW_MANY; i++) {
			thePings[i] = new Ping(i, sync);
			thePongs[i] = new Pong(i, sync);
			theBangs[i] = new Bang(i, sync);
			thePings[i].start();
			thePongs[i].start();
			theBangs[i].start();
		}
		
		Synchronizer.sleepAWhile(20000);
		
		kitkat.stop();
		for (int i=0; i<HOW_MANY; i++) {
			thePings[i].stop();
			thePongs[i].stop();
			theBangs[i].stop();
		}
	}

}

class Synchronizer {
	
	
	private ReentrantLock lock = new ReentrantLock();
	private volatile int turn; /* INITIALIZE variable turn here */
	
	/* Declare your other primitive-typed variables and constants here */
	public int PING = 0;
	public boolean PONG = false;
	public boolean BANG = false;
	
	public void letMePing() {
		lock.lock();
		while (turn!=PING) {
			/* COMPLETE */
			lock.unlock();
			try {
				lock.wait(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			lock.lock();
		}
		// when this point is reached, turn==PING and invoking thread owns the lock 
	}
	
	public  void letMePong() {
		/* COMPLETE */
		/* COMPLETE */
		lock.unlock();
		try {
			lock.wait(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}lock.lock();
	}
	
	public void letMeBang() {
		/* COMPLETE */
		lock.lock();
		while(turn==PING) {
			lock.unlock();
			//yield();
			lock.lock();
		}
		
	}

	public void pingDone() {
		/* COMPLETE */
		PING = 0;
		PONG = true;
		
		lock.unlock();
	}

	public void pongDone() {
		PONG = false;
		BANG = true;
		
		lock.unlock();
	}
	
	public void bangDone() {
		/* COMPLETE */
	}
	
	/* add your kit-kat-related methods here */
	
	
	//-------------------------------------------------
	
	// convenience method.
	protected static void sleepAWhile(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException ie) {
		}
	}
}


class KitKat extends Thread {
	private Synchronizer synchronizer;

	public KitKat(Synchronizer synchronizer) {
		this.synchronizer = synchronizer;
	}

	public void run() {
		/* COMPLETE */
	}
}

/* Classes Ping, Pong and Bang are complete. 
 * DO NOT MODIFY THEM */

class Ping extends Thread {
	private int id;
	private Synchronizer synchronizer;
	
	public Ping (int id, Synchronizer synchronizer) {
		this.synchronizer = synchronizer;
		this.id = id;}
	
	public void run () {
		while (true) {
			synchronizer.letMePing();
			System.out.print("PING("+id+") ");
			synchronizer.pingDone();
		}
	}
}

class Pong extends Thread {
	private int id;
	private Synchronizer synchronizer;
	
	public Pong (int id, Synchronizer synchronizer) {
		this.synchronizer = synchronizer;
		this.id = id;}
	
	public void run () {
		while (true) {
			synchronizer.letMePong();
			System.out.print("pong("+id+") ");
			synchronizer.pongDone();
		}
	}
}

class Bang extends Thread {
	private int id;
	private Synchronizer synchronizer;
	
	public Bang (int id, Synchronizer synchronizer) {
		this.synchronizer = synchronizer;
		this.id = id;}
	
	public void run () {
		while (true) {
			synchronizer.letMeBang();
			System.out.println("BANG!("+id+")");
			synchronizer.bangDone();
		}
	}
}
