package exer_05_CamelRace;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JProgressBar;
import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.ComponentOrientation;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;


public class CamelRaceProgram extends JFrame implements ActionListener {
	private JPanel contentPanel;
	private JProgressBar pb1;
	private JLabel labe1;
	private JProgressBar pb2;
	private JLabel labe2;
	private JProgressBar pb3;
	private JLabel labe3;
	private JButton startBtn;
	private JTextArea raceInfo;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CamelRaceProgram frame = new CamelRaceProgram();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public CamelRaceProgram() {
		this.setTitle("Ignasi Oliver Camel Race");
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setBounds(100, 100, 800, 400);
	    this.contentPanel = new JPanel();
	    this.contentPanel.setLayout(new GridLayout(2,2,5,10));
	    this.contentPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
	    this.contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
	    this.setContentPane(this.contentPanel);
	    JPanel contentCamels = new JPanel();
	    contentCamels.setLayout(new GridLayout(3, 2, 5, 5));
	    contentCamels.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
	    this.pb1 = new JProgressBar(0, 100);
	    this.pb1.setStringPainted(true);
	    this.pb1.setForeground(Color.BLUE);
	    this.labe1 = new JLabel("Camel 1");
	    this.pb2 = new JProgressBar(0, 100);
	    this.pb2.setStringPainted(true);
	    this.pb2.setForeground(Color.RED);
	    this.labe2 = new JLabel("Camel 2");
	    this.pb3 = new JProgressBar(0, 100);
	    this.pb3.setStringPainted(true);
	    this.pb3.setForeground(Color.GREEN);
	    this.labe3 = new JLabel("Camel 3");
	    this.startBtn = new JButton("Start Race");
	    this.startBtn.addActionListener(this);
	    this.raceInfo = new JTextArea("");
	    this.raceInfo.enableInputMethods(false);
	    this.raceInfo.setBorder(new TitledBorder(null,
	    		"Race Info",
	    		TitledBorder.LEADING,
	    		TitledBorder.TOP,
	    		null,
	    		null));
	    
	    contentCamels.add(labe1);
	    contentCamels.add(pb1);
	    contentCamels.add(labe2);
	    contentCamels.add(pb2);
	    contentCamels.add(labe3);
	    contentCamels.add(pb3);
	    contentPanel.add(contentCamels);
	    contentPanel.add(raceInfo);
	    this.add(startBtn);
	}
	
	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == this.startBtn) startBtnActionPerformed(ae);
	}

	protected void startBtnActionPerformed(ActionEvent ae) {
		this.startBtn.setEnabled(false);
		this.raceInfo.enableInputMethods(false);
		Camel[] CamelList = new Camel[3];
		CamelList[0] = new Camel(this.labe1.getText(), this.pb1);
		CamelList[1] = new Camel(this.labe2.getText(), this.pb2);
		CamelList[2] = new Camel(this.labe3.getText(), this.pb3);
		Referee r = new Referee(CamelList, this.raceInfo, this.startBtn);
		r.start();
		for (Camel c : CamelList) c.start();

	}

}

