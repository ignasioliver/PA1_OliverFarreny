package exer_05_CamelRace;

import javax.swing.*;


public class Referee extends Thread {
	
	private Camel [] theCamels;
	private JTextArea textArea;
	private JButton button;
	
	public Referee (Camel [] theCamels, JTextArea textArea, JButton button) {
		this.theCamels = theCamels;
		this.textArea = textArea;
		this.button = button;
	}
	
	public void run () {
		/* COMPLETE */
		int crossedFnshLine = -1;
		while (true) { 
			crossedFnshLine = getWinner();
			if (crossedFnshLine != -1) {
				writeWinner(crossedFnshLine);
				stopTheCamels(); 
				this.stop();
			}
		}
	}
	
	/* COMPLETE IF NECESSARY */
	private int getWinner() {
		for (int i=0; i < theCamels.length; i++) {
			if(theCamels[i].getProgress() == 100) {
				return i;
			}
		}
		return -1;
	}
	
	private void stopTheCamels() {
		for(Camel c : theCamels) {
			c.stop();
		}
		button.setEnabled(true);
	}
	
	private void writeWinner(int w) {
		this.textArea.append("The WINNER is camel #" + (w+1) + "\n");
	}
}
