package exer_05_CamelRace;

import javax.swing.*;
import java.util.*;


public class Camel extends Thread {
	
	private Random alea = new Random();
	private JProgressBar bar;
	private String name;
	private int progress=0;
	private int t;
	
	public Camel (String name, JProgressBar bar) {
		this.name = name;
		this.bar = bar;
	}
	
	public String getTheName() {return this.name;}
	public int getProgress() {return this.progress;}
	
	public void run () {
		/* COMPLETE */
		while(progress < 100) {
			progress++; 
			bar.setValue(progress);
			t=alea.nextInt(11)+40;
			try {Thread.sleep(t);}
			catch (InterruptedException e) {}
		}
	}
	
	
	/* COMPLETE IF NECESSARY */

}
