package exer_01_PPB_WITH_KK;


public class Exer_01_PPB_WITH_KK {
	// LAUNCHER
	public static void main(String[] args) {
		
		Synchronizer sync = new Synchronizer();
		Ping ping = new Ping(sync);
		Pong pong = new Pong(sync);
		Bang bang = new Bang(sync);
		KitKat kitKat = new KitKat(sync);
		
		System.out.println("lets go");
		
		kitKat.start();
		ping.start();
		pong.start();
		bang.start();
		
		Synchronizer.sleepAWhile(20000);
		
		ping.stop();
		pong.stop();
		bang.stop();
		kitKat.stop();
	}
}

class Synchronizer {
	
	/* declare your primitive-typed variables here */
	private volatile boolean canPing = true;
	private volatile int canPong = 0;
	private volatile boolean canBang = false;
	private volatile boolean canKitKat = false;
	private volatile boolean KitKatWaiting = false;
	
	
	public Synchronizer() {}
	
	public void letMePing() {
		/* COMPLETE */
		while(!canPing) {
			sleepAWhile(20);
		}
		
	}
	
	public void letMePong() {
		/* COMPLETE */
		while(canPong == 0){
			sleepAWhile(20);
		}
		canPong--;
	}
	
	public void letMeBang() {
		/* COMPLETE */
		while(!canBang) {
			sleepAWhile(20);
		}
	}
	
	public void pingDone() {
		/* COMPLETE */
		canPing = false;
		canPong = 2;
	}
	
	public void pongDone() {
		/* COMPLETE */
		if (canPong == 0) {
			if (KitKatWaiting) {
				canKitKat = true;
			} else {
				canBang = true;
			}
		}
	}
	
	public void bangDone() {
		/* COMPLETE */
		canBang = false;
		if(KitKatWaiting) {
			canKitKat = true;
		} else {
			canPing = true;
		}
	}
	
	
	/* add your kit-kat-related methods here */
	public void letMeKitKat() {
		this.KitKatWaiting = true;
		while(!canKitKat) {
			sleepAWhile(200);
		}
		
	}
	public void kitKatDone () {
		canKitKat = false;
		this.KitKatWaiting = false;
		canPing = true;
	}
		
	//----------------------------------------------------
	
	// convenience method.
	protected static void sleepAWhile (int ms) {
		try {Thread.sleep(ms);}
		catch(InterruptedException ie) {}
	}
}


class KitKat extends Thread {
	private Synchronizer synchronizer;

	public KitKat(Synchronizer synchronizer) {
		this.synchronizer = synchronizer;
	}

	public void run() {
		/* COMPLETE */
		while (true) {
			synchronizer.letMeKitKat();
			System.out.print("\n\tKIT KAT: ");
			for(int i = 9; i >= 0;  i--) {
				System.out.print(i+" ");
				synchronizer.sleepAWhile(200);
			}
			System.out.println();
			synchronizer.kitKatDone();
			synchronizer.sleepAWhile(500);
		}
	}
}

/* Classes Ping, Pong and Bang are complete. 
 * DO NOT MODIFY THEM */

class Ping extends Thread {
	private Synchronizer synchronizer;
	
	public Ping (Synchronizer synchronizer) {
		this.synchronizer = synchronizer; }
	
	public void run () {
		while (true) {
			synchronizer.letMePing();
			System.out.print("PING ");
			synchronizer.pingDone();
		}
	}
}

class Pong extends Thread {
	private Synchronizer synchronizer;
	
	public Pong (Synchronizer synchronizer) {
		this.synchronizer = synchronizer;}
	
	public void run () {
		while (true) {
			synchronizer.letMePong();
			System.out.print("pong ");
			synchronizer.pongDone();
		}
	}
}

class Bang extends Thread {

	private Synchronizer synchronizer;
	
	public Bang (Synchronizer synchronizer) {
		this.synchronizer = synchronizer;}
	
	public void run () {
		while (true) {
			synchronizer.letMeBang();
			System.out.println("BANG!");
			synchronizer.bangDone();
		}
	}
}
